# CoConnect- Ecommerce Website
 Ecommerce Website using HTML, CSS, JS,PHP,MYSQL
# Features
1. Login
2. Logout
3. Signup
4. Newsletter
5. Extensive and Aesthetic Mobile and Desktop view
![Screenshot 1](img/Picture1.png)
![Screenshot 2](img/Picture2.png)


